
package brickbreaker;

import javax.swing.JFrame;

public class BrickBreaker {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Gameplay gameplay = new Gameplay();
        JFrame obj = new JFrame();
        obj.setBounds(10,10,700,600);//size
        obj.setTitle("Brick Breaker");
        obj.setResizable(false);
        obj.setVisible(true); 
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        obj.add(gameplay);// add this object
        
    }
    
}
