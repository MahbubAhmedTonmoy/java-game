
package brickbreaker;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author mahbub
 */
public class Gameplay extends JPanel implements KeyListener,ActionListener{ 
// key-- press arrow key , action -- moving the ball
   
    private boolean play = false; // start it shouldn't play it self
    private int score = 0;
    
    private int totalBricks = 28;
    private Timer timer;// how first ball move
    private int delay = 7;
    
    private int playerX = 310;// slider position sart
    
    private int ballposX = 120; // ball position x
    private int ballposY = 350;// ball y
    
    private int ballXdir = -1;//set direction of the ball
    private int ballYdir = -2;
    
    private MapGenerator map;
    
    public Gameplay(){
        map = new MapGenerator(4,7);
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        timer = new Timer(delay,this);/// speed,context
        timer.start();
    }
    
    public void paint(Graphics g){
        
        //background
        g.setColor(Color.BLACK);
        g.fillRect(1,1,692,592);// rectangle for background
        
        //drawing map
        map.draw((Graphics2D)g);
        
        
        //borders
        g.setColor(Color.ORANGE);
        g.fillRect(0,0,3,592);//left
        g.fillRect(0,0,692,3); // upper
        g.fillRect(691,0,3,592);//right
        
        //scores 
        g.setColor(Color.GREEN);
        g.setFont(new Font("Serif",Font.BOLD,25));
        g.drawString(""+score, 590, 30);
        
        
        //the paddle
        g.setColor(Color.blue);
        g.fillRect(playerX,550,100,8);
        
        //the ball
        g.setColor(Color.yellow);
        g.fillOval(ballposX,ballposY,20,20);//squre 
        
        if(totalBricks<=0){
            play = false;
            ballXdir = 0;
            ballYdir = 0;
            g.setColor(Color.WHITE);
            g.setFont(new Font("serif",Font.BOLD,30));
            g.drawString("You Won!",270,300);
            
             g.setFont(new Font("serif",Font.BOLD,20));
            g.drawString("Press Enter to Restart ",230,350);
        }
        
        if(ballposY > 570){
            play = false;
            ballXdir = 0;
            ballYdir = 0;
            g.setColor(Color.WHITE);
            g.setFont(new Font("serif",Font.BOLD,30));
            g.drawString("You Failed! Score : "+score,190,300);
            
             g.setFont(new Font("serif",Font.BOLD,20));
            g.drawString("Press Enter to Restart ",230,350);
            
        }
        
        g.dispose();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        timer.start();
        if(play){
            if(new Rectangle(ballposX,ballposY,20,20).intersects(new Rectangle(playerX,550,100,8))){
                ballYdir = -ballYdir;//touch paddel then move to upper
            }
            A: for(int i=0;i<map.map.length;i++){ //private MapGenerator map variable
                for(int j =0;j<map.map[0].length;j++){//map[][]
                    if(map.map[i][j]>0){
                        int brickX = j*map.brickwidth +80;
                        int brickY = i* map.brickheight +50;
                        int brickwidth = map.brickwidth;
                        int brickheight = map.brickheight;
                        
                        Rectangle rect = new Rectangle(brickX,brickY,brickwidth,brickheight);//rectangle around the brick
                        Rectangle ballRect = new Rectangle(ballposX,ballposY,20,20);//rectangle around the ball
                        Rectangle brickRect = rect;
                        
                        if(ballRect.intersects(brickRect)){
                            map.setBrickValue(0, i, j);
                            totalBricks--;
                            score +=5;
                            
                            if(ballposX+19  <= brickRect.x || ballposX+1 >=brickRect.x + brickRect.width){
                                ballXdir = -ballXdir;//oposite direction;
                                System.out.println(ballposX +"  "+ brickRect.x +"  "+brickRect.width);
                            }
                            else{
                                ballYdir = -ballYdir;//towards top/bottom 
                                
                            }
                            break A;
                        }
                    }
                }
            }
            ballposX += ballXdir;
            ballposY += ballYdir;
            if(ballposX<0){//left
                ballXdir = -ballXdir;
            }
            if(ballposY<0){//top
                ballYdir = -ballYdir;
            }
            if(ballposX>670){//right
                ballXdir = -ballXdir;
            }
        }
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
      @Override
    public void keyReleased(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        if(e.getKeyCode()== KeyEvent.VK_RIGHT){
            if(playerX >= 600){//check out side the panel
                playerX = 600;
            }else{
                moveRight();
            }
        }
        if(e.getKeyCode()== KeyEvent.VK_LEFT){
            if(playerX < 10){
                playerX = 10;
            }else{
                moveLeft();
            }
        }
        if(e.getKeyCode() == KeyEvent.VK_ENTER){
            if(!play){
                play = true;
                ballposX = 120;
                ballposY = 350;
                ballXdir = -1;
                ballYdir = -2;
                playerX = 310;
                score = 0;
                totalBricks = 28;
                map = new MapGenerator(4,7);
                
                repaint();
            }
        }
        
    }
    public void moveRight(){
        play = true; //at first it false
        playerX+=20;
    }
    public void moveLeft(){
        play = true;
        playerX-=20;
    }   
}
